// Enhanced DVN View - Shows comprehensive DVN performance analytics
import React, { useMemo } from 'react';
import { ArrowLeft, TrendingUp, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { formatUsd, formatLatency, formatPercent } from '../../utils/format';
import { getAssetDisplayName, getAssetSymbol } from '../../utils/assetRegistry';
import { getDVNName } from '../../utils/dvnRegistry';

export default function EnhancedDvnView({ data, dvnAddress, onBack }) {
  const dvnName = getDVNName(dvnAddress, 30184) || dvnAddress;
  
  // Filter transactions for this DVN
  const dvnTransactions = useMemo(() => {
    if (!data?.transactions) return [];
    
    return data.transactions.filter(tx => {
      const required = tx.required_dvn_addresses || [];
      const optional = tx.optional_dvn_addresses || [];
      return required.includes(dvnAddress) || optional.includes(dvnAddress);
    });
  }, [data, dvnAddress]);
  
  // Calculate role distribution
  const roleStats = useMemo(() => {
    let required = 0, optional = 0;
    
    dvnTransactions.forEach(tx => {
      const requiredDvns = tx.required_dvn_addresses || [];
      const optionalDvns = tx.optional_dvn_addresses || [];
      
      if (requiredDvns.includes(dvnAddress)) required++;
      if (optionalDvns.includes(dvnAddress)) optional++;
    });
    
    return { required, optional, total: required + optional };
  }, [dvnTransactions, dvnAddress]);
  
  // Group by OAPP
  const oappsUsingDvn = useMemo(() => {
    const oapps = {};
    
    dvnTransactions.forEach(tx => {
      const oappAddr = tx.oapp_address;
      if (!oappAddr) return;
      
      if (!oapps[oappAddr]) {
        oapps[oappAddr] = {
          address: oappAddr,
          name: tx.oapp_name || getAssetDisplayName(oappAddr),
          transactions: [],
          volume: 0,
          delivered: 0,
          failed: 0
        };
      }
      
      oapps[oappAddr].transactions.push(tx);
      oapps[oappAddr].volume += parseFloat(tx.amount_usd || 0);
      
      if (tx.delivery_status === 'DELIVERED') {
        oapps[oappAddr].delivered++;
      } else {
        oapps[oappAddr].failed++;
      }
    });
    
    return Object.values(oapps)
      .map(o => ({
        ...o,
        successRate: o.transactions.length > 0 
          ? ((o.delivered / o.transactions.length) * 100).toFixed(1)
          : 0
      }))
      .sort((a, b) => b.volume - a.volume);
  }, [dvnTransactions]);
  
  // Group by route
  const routePerformance = useMemo(() => {
    const routes = {};
    
    dvnTransactions.forEach(tx => {
      const route = `${tx.source_chain_name || 'Unknown'}→${tx.destination_chain_name || 'Unknown'}`;
      
      if (!routes[route]) {
        routes[route] = {
          route,
          transactions: [],
          totalLatency: 0,
          delivered: 0,
          failed: 0
        };
      }
      
      routes[route].transactions.push(tx);
      routes[route].totalLatency += parseFloat(tx.latency_seconds || 0);
      
      if (tx.delivery_status === 'DELIVERED') {
        routes[route].delivered++;
      } else {
        routes[route].failed++;
      }
    });
    
    return Object.values(routes)
      .map(r => ({
        ...r,
        avgLatency: r.transactions.length > 0 
          ? (r.totalLatency / r.transactions.length).toFixed(1)
          : 0,
        successRate: r.transactions.length > 0
          ? ((r.delivered / r.transactions.length) * 100).toFixed(1)
          : 0
      }))
      .sort((a, b) => b.transactions.length - a.transactions.length);
  }, [dvnTransactions]);
  
  // Co-DVN analysis (which other DVNs appear in same stacks)
  const coDvnStats = useMemo(() => {
    const coDvns = {};
    
    dvnTransactions.forEach(tx => {
      const allDvns = [
        ...(tx.required_dvn_addresses || []),
        ...(tx.optional_dvn_addresses || [])
      ];
      
      allDvns.forEach(addr => {
        if (addr === dvnAddress) return; // Skip self
        
        if (!coDvns[addr]) {
          coDvns[addr] = {
            address: addr,
            name: getDVNName(addr, 30184) || addr.slice(0, 10) + '...',
            count: 0,
            delivered: 0,
            failed: 0
          };
        }
        
        coDvns[addr].count++;
        if (tx.delivery_status === 'DELIVERED') {
          coDvns[addr].delivered++;
        } else {
          coDvns[addr].failed++;
        }
      });
    });
    
    return Object.values(coDvns)
      .map(d => ({
        ...d,
        successRate: d.count > 0 
          ? ((d.delivered / d.count) * 100).toFixed(1)
          : 0
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, [dvnTransactions, dvnAddress]);
  
  // Overall stats
  const overallStats = useMemo(() => {
    const total = dvnTransactions.length;
    const delivered = dvnTransactions.filter(tx => tx.delivery_status === 'DELIVERED').length;
    const totalVolume = dvnTransactions.reduce((sum, tx) => sum + parseFloat(tx.amount_usd || 0), 0);
    const totalLatency = dvnTransactions.reduce((sum, tx) => sum + parseFloat(tx.latency_seconds || 0), 0);
    
    return {
      total,
      delivered,
      failed: total - delivered,
      successRate: total > 0 ? ((delivered / total) * 100).toFixed(1) : 0,
      totalVolume,
      avgLatency: total > 0 ? (totalLatency / total).toFixed(1) : 0
    };
  }, [dvnTransactions]);
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button 
          onClick={onBack}
          className="p-2 hover:bg-gray-800 rounded"
        >
          <ArrowLeft size={20} />
        </button>
        <div>
          <h2 className="text-2xl font-bold">{dvnName}</h2>
          <p className="text-sm text-gray-400 font-mono">{dvnAddress}</p>
        </div>
      </div>
      
      {/* Overview Stats */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-4">
          <div className="text-xs text-gray-400 mb-1">TOTAL TRANSACTIONS</div>
          <div className="text-2xl font-bold">{overallStats.total.toLocaleString()}</div>
          <div className="text-xs text-emerald-400">{overallStats.delivered} delivered</div>
        </div>
        
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-4">
          <div className="text-xs text-gray-400 mb-1">TOTAL VOLUME</div>
          <div className="text-2xl font-bold">{formatUsd(overallStats.totalVolume)}</div>
          <div className="text-xs text-gray-400">Cross-chain verified</div>
        </div>
        
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-4">
          <div className="text-xs text-gray-400 mb-1">SUCCESS RATE</div>
          <div className="text-2xl font-bold text-emerald-300">{overallStats.successRate}%</div>
          <div className="text-xs text-red-400">{overallStats.failed} failed</div>
        </div>
        
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-4">
          <div className="text-xs text-gray-400 mb-1">AVG LATENCY</div>
          <div className="text-2xl font-bold">{formatLatency(overallStats.avgLatency)}</div>
          <div className="text-xs text-gray-400">Verification time</div>
        </div>
      </div>
      
      {/* Role Distribution */}
      <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
        <h3 className="font-bold mb-4 flex items-center gap-2">
          <CheckCircle size={16} className="text-blue-400" />
          DVN ROLE DISTRIBUTION
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-black border border-gray-800 rounded p-4">
            <div className="text-xs text-gray-400 mb-1">REQUIRED DVN</div>
            <div className="text-xl font-bold text-blue-300">{roleStats.required.toLocaleString()} tx</div>
            <div className="text-xs text-gray-400">
              {roleStats.total > 0 ? ((roleStats.required / roleStats.total) * 100).toFixed(0) : 0}% of total
            </div>
          </div>
          
          <div className="bg-black border border-gray-800 rounded p-4">
            <div className="text-xs text-gray-400 mb-1">OPTIONAL DVN</div>
            <div className="text-xl font-bold text-purple-300">{roleStats.optional.toLocaleString()} tx</div>
            <div className="text-xs text-gray-400">
              {roleStats.total > 0 ? ((roleStats.optional / roleStats.total) * 100).toFixed(0) : 0}% of total
            </div>
          </div>
        </div>
      </div>
      
      {/* Top OAPPs */}
      <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
        <h3 className="font-bold mb-4 flex items-center gap-2">
          <TrendingUp size={16} className="text-emerald-400" />
          TOP OAPPs USING THIS DVN
        </h3>
        <div className="space-y-2">
          {oappsUsingDvn.slice(0, 10).map((oapp, i) => (
            <div key={i} className="bg-black border border-gray-800 rounded p-3 flex items-center justify-between">
              <div>
                <div className="font-medium text-sm">{oapp.name}</div>
                <div className="text-xs text-gray-500">{oapp.transactions.length} tx</div>
              </div>
              <div className="text-right">
                <div className="text-sm font-semibold">{formatUsd(oapp.volume)}</div>
                <div className={`text-xs ${
                  parseFloat(oapp.successRate) >= 95 ? 'text-emerald-400' : 'text-yellow-400'
                }`}>
                  {oapp.successRate}% success
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Route Performance */}
      <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
        <h3 className="font-bold mb-4 flex items-center gap-2">
          <Clock size={16} className="text-yellow-400" />
          PERFORMANCE BY ROUTE
        </h3>
        <div className="space-y-2">
          {routePerformance.slice(0, 10).map((route, i) => (
            <div key={i} className="bg-black border border-gray-800 rounded p-3 flex items-center justify-between">
              <div>
                <div className="font-medium text-sm">{route.route}</div>
                <div className="text-xs text-gray-500">{route.transactions.length} tx</div>
              </div>
              <div className="text-right">
                <div className="text-sm font-semibold">{formatLatency(route.avgLatency)}</div>
                <div className={`text-xs ${
                  parseFloat(route.successRate) >= 95 ? 'text-emerald-400' : 'text-yellow-400'
                }`}>
                  {route.successRate}% success
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* DVN Stack Combinations */}
      <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
        <h3 className="font-bold mb-4 flex items-center gap-2">
          <AlertCircle size={16} className="text-purple-400" />
          COMMON DVN STACK PARTNERS
        </h3>
        <p className="text-xs text-gray-400 mb-4">
          Which other DVNs frequently appear alongside {dvnName} in verification stacks
        </p>
        <div className="space-y-2">
          {coDvnStats.map((dvn, i) => (
            <div key={i} className="bg-black border border-gray-800 rounded p-3 flex items-center justify-between">
              <div>
                <div className="font-medium text-sm">{dvn.name}</div>
                <div className="text-xs text-gray-500">Co-verified {dvn.count} times</div>
              </div>
              <div className="text-right">
                <div className={`text-sm font-semibold ${
                  parseFloat(dvn.successRate) >= 95 ? 'text-emerald-400' : 'text-yellow-400'
                }`}>
                  {dvn.successRate}%
                </div>
                <div className="text-xs text-gray-400">success rate</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
